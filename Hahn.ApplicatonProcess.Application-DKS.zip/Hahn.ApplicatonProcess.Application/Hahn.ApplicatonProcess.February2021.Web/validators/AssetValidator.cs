﻿using FluentValidation;
using Hahn.ApplicatonProcess.February2021.Data.Handlers;
using System;
using static Hahn.ApplicatonProcess.February2021.Domain.Enums.Application;

namespace Hahn.ApplicatonProcess.February2021.Web.validators
{
    public class AssetValidator : AbstractValidator<AssetVm>
    {
        public AssetValidator()
        {
            RuleFor(x => x.AssetName)
                .NotEmpty().WithMessage("Please provide the Asset name")
                .MinimumLength(5).WithMessage("Please provide Asset name with at least 5 Characters");

            RuleFor(x => x.Department)
                .NotEmpty().WithMessage("Please selected Department")
                .IsEnumName(typeof(Department)).WithMessage("Please provide valid department");

            RuleFor(x => x.EMailAdressOfDepartment)
                .NotEmpty().WithMessage("Please ensure you have entered the Department Email")
                .EmailAddress().WithMessage("Please provide valid Department Email");

            RuleFor(x => x.PurchaseDate)
                .NotEmpty().WithMessage("Please ensure you have selected Purchase Date")
                //.GreaterThan(System.DateTime.Now.AddDays(-30))
                .GreaterThan(p => DateTime.UtcNow.AddYears(-1)).WithMessage("Please ensure you have entered valid Purchase date, not older then a year")
                .LessThanOrEqualTo(System.DateTime.UtcNow)
                .WithMessage("Please provide valid Purchase Date within current date and any date from past 30 Days");
                //.LessThan(p => DateTime.Now.AddYears(-1)).WithMessage("Please ensure you have entered valid Purchase date, not older then a year");
        }
    }
}
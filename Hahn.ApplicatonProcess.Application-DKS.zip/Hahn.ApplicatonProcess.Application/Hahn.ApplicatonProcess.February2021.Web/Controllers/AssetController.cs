﻿using Hahn.ApplicatonProcess.February2021.Data.Handlers.Commands;
using Hahn.ApplicatonProcess.February2021.Data.Handlers.Queries;
using Hahn.ApplicatonProcess.February2021.Domain.Entities;
using Hahn.ApplicatonProcess.February2021.Web.Utils;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.February2021.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
  
    public class AssetController : ControllerBase
    {
        private readonly IStringLocalizer<AssetController> _localizer;

        // HttpClient is intended to be instantiated once per application, rather than per-use. 
        private static readonly HttpClient _client = new HttpClient();
        private readonly ILogger _logger;
        private readonly IMediator _mediator;

        public AssetController(IStringLocalizer<AssetController> localizer, IMediator mediator, ILogger<AssetController> logger)
        {
            _localizer = localizer ?? throw new ArgumentNullException(nameof(localizer));
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetAsset()
        {
            try
            {
                _logger.LogInformation(_localizer[ "Controller method {methodname} has requested @{date}"], "GetAsset",  DateTime.Now);
                var response = await _mediator.Send(new GetAsset());
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(_localizer["Exception has occured in Controller {controllername}, method {methodname}, encountered @{date}, exception details {exceptionmessage}"]
                        , "AssetController", "GetAsset", DateTime.Now, ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, (_localizer["Error while {operation} data!"], _localizer["retrieving"]));
            }
        }

        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetAssetById(int id)
        {
            try
            {
                _logger.LogInformation(_localizer["Controller method {methodname} has requested @{date}"], "GetAssetById", DateTime.Now);
                var response = await _mediator.Send(new GetAssetById { Id = id });
                if (response == null)
                {
                    return NotFound();
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(_localizer["Exception has occured in Controller {controllername}, method {methodname}, requested id# {id}, encountered @{date}, exception details {exceptionmessage}"]
                        , "AssetController", "GetAssetById", id, DateTime.Now, ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, (_localizer["Error while {operation} data!"], _localizer["retrieving"]));
            }
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateAsset(CreateAsset command)
        {
            try
            {
                _logger.LogInformation(_localizer["Controller method {methodname} has requested @{date}"], "CreateAsset", DateTime.Now);
                string  result = await Countries.GetCountryById(command.CountryOfDepartment);
                if(result == "OK")
                {
                    var response = await _mediator.Send(command);

                    if (response == 1)
                    {
                        return Ok(StatusCode(201));
                    }
                    else
                    {
                        return BadRequest(StatusCode(400));
                    }
                }
                else
                {
                    _logger.LogError(_localizer["{modelname} - {modelvalue} is not valid!"], "CountryOfDepartment", command.CountryOfDepartment, DateTime.Now);
                    return StatusCode(StatusCodes.Status400BadRequest, (_localizer["{modelname} is not valid!"], "CountryOfDepartment"));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(_localizer["Exception has occured in Controller {controllername}, method {methodname}, encountered @{date}, exception details {exceptionmessage}"]
                        , "AssetController", "CreateAsset", DateTime.Now, ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, (_localizer["Error while {operation} data!"], _localizer["storing"]));
            }
        }

        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateAsset(int id, UpdateAsset command)
        {
            try
            {
                _logger.LogInformation(_localizer["Controller method {methodname} has requested @{date}"], "UpdateAsset", DateTime.Now);
                if (id !=  command.Id)
                {
                    _logger.LogError(_localizer["Error while {operation} data!, requested# {id}, @{datetime}"], _localizer["updating"], id, DateTime.Now);
                    return BadRequest();
                }

                string result = await Countries.GetCountryById(command.CountryOfDepartment);
                if (result == "OK")
                {
                    var response = await _mediator.Send(command);

                    if (response == 1)
                    {
                        return Ok(StatusCode(201));
                    }
                    else
                    {
                        return BadRequest(StatusCode(400));
                    }
                }
                else
                {
                    _logger.LogError(_localizer["{modelname} - {modelvalue} is not valid!"], "CountryOfDepartment", command.CountryOfDepartment, DateTime.Now);
                    return StatusCode(StatusCodes.Status400BadRequest, (_localizer["{modelname} is not valid!"], "CountryOfDepartment"));
                }
            }
            catch(Exception ex)
            {
                _logger.LogError(_localizer["Exception has occured in Controller {controllername}, method {methodname}, encountered @{date}, exception details {exceptionmessage}"]
                        , "AssetController", "UpdateAsset", DateTime.Now, ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, (_localizer["Error while {operation} data!"], _localizer["updating"]));
            }
        }
    
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> DeleteAsset(int id)
        {
            try
            {
                _logger.LogInformation(_localizer["Controller method {methodname} has requested @{date}"], "DeleteAsset", DateTime.Now);
                var response = await _mediator.Send(new DeleteAsset { Id = id });
                if (response == 1)
                {
                    return Ok(StatusCode(201));
                }
                else
                {
                    return BadRequest(StatusCode(400));
                }
            }
            catch(Exception ex)
            {
                _logger.LogError(_localizer["Exception has occured in Controller {controllername}, method {methodname}, encountered @{date}, exception details {exceptionmessage}"]
                        , "AssetController", "DeleteAsset", DateTime.Now, ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, (_localizer["Error while {operation} data!"], _localizer["deleting"]));
            }
        }

        [HttpGet("[action]")]
        public async Task<IEnumerable<Country>> GetCountry()
        {
            _logger.LogInformation(_localizer["Controller method {methodname} has requested @{date}"], "GetCountry", DateTime.Now);
            var response = await _client.GetAsync("https://restcountries.eu/rest/v2/all");

            string resBody = response.Content.ReadAsStringAsync().Result;
            List<Country> countries = JsonConvert.DeserializeObject<List<Country>>(resBody, new JsonSerializerSettings()
            {
                NullValueHandling = NullValueHandling.Ignore
            });

            return countries;
        }

        [HttpGet("[action]")]
        public async Task<IEnumerable<Department>> GetDepartment()
        {
            _logger.LogInformation(_localizer["Controller method {methodname} has requested @{date}"], "GetDepartment", DateTime.Now);

            List<Department> departments = Enum.GetValues(typeof(Domain.Enums.Application.Department))
                                                .Cast<Domain.Enums.Application.Department>()
                                                .Select(d => new Department { Name = d.ToString(), Value = Convert.ToString((int)d) })
                                                .ToList();
            return departments;
        }
    }
}
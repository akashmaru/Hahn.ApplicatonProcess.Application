﻿using Hahn.ApplicatonProcess.February2021.Data.Handlers;
using Hahn.ApplicatonProcess.February2021.Domain.Entities;
using Hahn.ApplicatonProcess.February2021.Domain.Repos;
using Hahn.ApplicatonProcess.February2021.Domain.Specifications;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.February2021.Data.Services
{
    public class AssetReadService : IAssetReadService
    {
        private readonly IGenericReadRepository _genericReadRepository;
        public AssetReadService(IGenericReadRepository genericReadRepository)
        {
            this._genericReadRepository = genericReadRepository ?? throw new ArgumentNullException(nameof(genericReadRepository)); ;
        }
 
        public async Task<IEnumerable<Asset>> GetAsset()
        {
            var spec = new AssetSpecification();
            return await _genericReadRepository.ListAsync(spec);
        }

        public async Task<IEnumerable<Asset>> GetAssetById(int id)
        {
            return await _genericReadRepository.ListByIdAsync<Asset>(id);
        }
    }
}
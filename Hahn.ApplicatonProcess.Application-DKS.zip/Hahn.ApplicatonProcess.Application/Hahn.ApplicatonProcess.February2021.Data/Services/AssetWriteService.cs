﻿using Hahn.ApplicatonProcess.February2021.Data.Handlers;
using Hahn.ApplicatonProcess.February2021.Domain.Entities;
using Hahn.ApplicatonProcess.February2021.Domain.Repos;
using System;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.February2021.Data.Services
{
    public class AssetWriteService : IAssetWriteService
    {
        private readonly IGenericWriteRepository _genericWriteRepository;

        public AssetWriteService(IGenericWriteRepository genericWriteRepository)
        {
            this._genericWriteRepository  = genericWriteRepository ?? throw new ArgumentNullException(nameof(genericWriteRepository)); ;
        }

        public async Task<int> CreateAsset(Asset asset)
        {
            return await _genericWriteRepository.SaveAsyn(asset);
        }      

        public async  Task<int> DeleteAsset(int id)
        {
            var data = await _genericWriteRepository.GetByIdAsync<Asset>(id);
            if (data == null)
            {
                return 0;
            }
            return await _genericWriteRepository.DeleteAsync(data);
        }
       
        public async Task<int> UpdateAsset(Asset asset)
        {
            return await _genericWriteRepository.UpdateAsync(asset);
        }
    }
}
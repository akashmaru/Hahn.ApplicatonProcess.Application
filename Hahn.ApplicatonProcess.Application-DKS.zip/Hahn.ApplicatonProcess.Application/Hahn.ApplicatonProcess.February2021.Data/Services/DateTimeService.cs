﻿using Hahn.ApplicatonProcess.February2021.Data.Common.Interfaces;
using Hahn.ApplicatonProcess.February2021.Data.Utils;
using System;

namespace Hahn.ApplicatonProcess.February2021.Data.Services
{
    public class DateTimeService : IDateTime
    {
        public DateTime Now => GetCurrentDateTime();

        public DateTime GetCurrentDateTime()
        {
            TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(DateTimeConfig.DEFAULT_TIME_ZONE);
            return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, timeZoneInfo);
        }
    }
}
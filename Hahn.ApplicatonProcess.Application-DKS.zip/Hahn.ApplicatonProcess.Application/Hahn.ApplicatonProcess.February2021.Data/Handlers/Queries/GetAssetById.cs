﻿using Hahn.ApplicatonProcess.February2021.Domain.Entities;
using MediatR;
using System.Collections.Generic;

namespace Hahn.ApplicatonProcess.February2021.Data.Handlers.Queries
{
    public class GetAssetById : IRequest<IEnumerable<Asset>>
    {
        public int Id { get; set; }
    }
}
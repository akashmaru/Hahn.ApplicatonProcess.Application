﻿using Hahn.ApplicatonProcess.February2021.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.February2021.Data.Handlers
{
    public interface IAssetReadService
    {
        public Task<IEnumerable<Asset>> GetAsset();
        public Task<IEnumerable<Asset>> GetAssetById(int id);
    }
}
﻿using MediatR;

namespace Hahn.ApplicatonProcess.February2021.Data.Handlers.Commands
{
    public class DeleteAsset : IRequest<int>
    {
        public int Id { get; set; }
    }
}
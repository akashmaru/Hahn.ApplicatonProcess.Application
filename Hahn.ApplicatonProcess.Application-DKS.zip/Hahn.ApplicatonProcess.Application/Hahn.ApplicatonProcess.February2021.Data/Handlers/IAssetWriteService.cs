﻿using Hahn.ApplicatonProcess.February2021.Domain.Entities;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.February2021.Data.Handlers
{
    public interface IAssetWriteService
    {
        public Task<int> CreateAsset(Asset asset);
        public Task<int> UpdateAsset(Asset asset);
        public Task<int> DeleteAsset(int id);
    }
}
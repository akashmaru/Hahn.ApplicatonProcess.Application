﻿using Hahn.ApplicatonProcess.February2021.Data.Common.Mappers;
using System;

namespace Hahn.ApplicatonProcess.February2021.Data.Handlers
{
    public class AssetVm : IMapFrom<Domain.Entities.Asset>
    {
        public int Id { get; set; }
        public string AssetName { get; set; }
        public string Department { get; set; }
        public string CountryOfDepartment { get; set; }
        public string EMailAdressOfDepartment { get; set; }
        public DateTime? PurchaseDate { get; set; }
        public bool broken { get; set; }
    }
}
﻿using System;

namespace Hahn.ApplicatonProcess.February2021.Data.Common.Interfaces
{
    public interface IDateTime
    {
        DateTime Now { get; }
    }
}

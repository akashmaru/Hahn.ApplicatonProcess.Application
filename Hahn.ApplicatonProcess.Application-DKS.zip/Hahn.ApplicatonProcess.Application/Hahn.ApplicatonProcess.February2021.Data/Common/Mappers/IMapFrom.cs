﻿using AutoMapper;

namespace Hahn.ApplicatonProcess.February2021.Data.Common.Mappers
{
    public interface IMapFrom<T>
    {
        void Mapping(Profile profile) => profile.CreateMap(typeof(T), GetType());
    }
}

﻿using Hahn.ApplicatonProcess.February2021.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Hahn.ApplicatonProcess.February2021.Domain.Context
{
    public class ApplicationContext : DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        {
        }

        public ApplicationContext() { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured == false)
            { 
            }
        }
        public virtual DbSet<Asset> Asset { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Asset>().HasData(
                    new Asset
                    {
                        Id = 1,
                        AssetName = "Akash Maru",
                        Department = Domain.Enums.Application.Department.HQ.ToString(),
                        CountryOfDepartment = "India",
                        EMailAdressOfDepartment = "akashmaru@gmail.com",
                        PurchaseDate = System.DateTime.Now,
                        broken = true
                    });
        }
    }
}
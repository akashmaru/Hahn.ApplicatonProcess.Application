﻿using Hahn.ApplicatonProcess.February2021.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.February2021.Data.Handlers.Queries
{
    public class GetAssetByIdHandler : IRequestHandler<GetAssetById, IEnumerable<Asset>>
    {
        private readonly IAssetReadService _assetReadService;
        public GetAssetByIdHandler(IAssetReadService assetService)
        {
            _assetReadService = assetService ?? throw new ArgumentNullException(nameof(assetService));
        }

        public async Task<IEnumerable<Asset>> Handle(GetAssetById request, CancellationToken cancellationToken)
        {
            var assets = await _assetReadService.GetAssetById(request.Id);
            return assets;
        }
    }
}
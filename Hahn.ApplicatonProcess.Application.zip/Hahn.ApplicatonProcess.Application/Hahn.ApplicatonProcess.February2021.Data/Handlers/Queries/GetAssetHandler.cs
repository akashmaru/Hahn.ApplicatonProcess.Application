﻿using Hahn.ApplicatonProcess.February2021.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.February2021.Data.Handlers.Queries
{
    public class GetAssetHandler : IRequestHandler<GetAsset, IEnumerable<Asset>>
    {
        private readonly IAssetReadService _assetReadService;
        public GetAssetHandler(IAssetReadService assetService)
        {
            _assetReadService = assetService ?? throw new ArgumentNullException(nameof(assetService));
        }

        public async Task<IEnumerable<Asset>> Handle(GetAsset request, CancellationToken cancellationToken)
        {
            var assets = await _assetReadService.GetAsset();
            return assets;
        }
    }
}
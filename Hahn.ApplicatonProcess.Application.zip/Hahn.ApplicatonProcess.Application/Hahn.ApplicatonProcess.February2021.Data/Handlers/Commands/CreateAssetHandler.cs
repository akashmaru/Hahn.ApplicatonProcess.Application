﻿using Hahn.ApplicatonProcess.February2021.Data.Common.Interfaces;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.February2021.Data.Handlers.Commands
{
    public class CreateAssetHandler : IRequestHandler<CreateAsset, int>
    {
        private readonly IAssetWriteService _assetWriteService;
        private readonly IDateTime _dateTime;

        public CreateAssetHandler(IAssetWriteService assetService, IDateTime dateTime)
        {
            _assetWriteService = assetService ?? throw new ArgumentNullException(nameof(assetService));
            _dateTime = dateTime ?? throw new ArgumentNullException(nameof(dateTime));

        }
        public async Task<int> Handle(CreateAsset request, CancellationToken cancellationToken)
        {
            var asset = new Domain.Entities.Asset
            {
                Id =  request.Id,
                AssetName = request.AssetName,
                Department = request.Department,
                CountryOfDepartment = request.CountryOfDepartment,
                EMailAdressOfDepartment = request.EMailAdressOfDepartment,
                PurchaseDate = request.PurchaseDate,
                broken = request.broken
            };

            int result =  await _assetWriteService.CreateAsset(asset);
            return result;
        }
    }
}
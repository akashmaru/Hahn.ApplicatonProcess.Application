﻿using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.February2021.Data.Handlers.Commands
{
    public class DeleteAssetHandler : IRequestHandler<DeleteAsset, int>
    {
        private readonly IAssetWriteService _assetWriteService;

        public DeleteAssetHandler(IAssetWriteService assetService)
        {
            _assetWriteService = assetService ?? throw new ArgumentNullException(nameof(assetService));
        }

        public async Task<int> Handle(DeleteAsset request, CancellationToken cancellationToken)
        {
            return await _assetWriteService.DeleteAsset(request.Id);
        }
    }
}
﻿using Hahn.ApplicatonProcess.February2021.Data.Common.Behaviours;
using Hahn.ApplicatonProcess.February2021.Data.Common.Interfaces;
using Hahn.ApplicatonProcess.February2021.Data.Handlers;
using Hahn.ApplicatonProcess.February2021.Data.Services;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace Hahn.ApplicatonProcess.February2021.Data.IoC
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services)
        {
            services.AddMediatR(Assembly.GetExecutingAssembly());

            //Transient lifetime services are created each time they are requested.
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidationBehaviour<,>));
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(LoggingBehaviour<,>));
            services.AddTransient<IDateTime, DateTimeService>();

            //Scoped lifetime services are created once per request within the scope.It is equivalent to a singleton in the current scope.
            services.AddScoped<IAssetReadService, AssetReadService>();
            services.AddScoped<IAssetWriteService, AssetWriteService>();
            return services;
        }           
    }
}
﻿namespace Hahn.ApplicatonProcess.February2021.Data.Utils
{
    public class DateTimeConfig
    {
        public static string DEFAULT_TIME_ZONE = "India Standard Time";
    }
}
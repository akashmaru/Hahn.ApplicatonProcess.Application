﻿using System;

namespace Hahn.ApplicatonProcess.February2021.Domain.Entities
{
    public class Asset  : BaseEntity
    {
        public string AssetName { get; set; }
        public string Department { get; set; }
        public string CountryOfDepartment { get; set; }
        public string EMailAdressOfDepartment { get; set; }
        public DateTime PurchaseDate { get; set; } // UTC DATETIME
        public bool broken { get; set; }
    }
}
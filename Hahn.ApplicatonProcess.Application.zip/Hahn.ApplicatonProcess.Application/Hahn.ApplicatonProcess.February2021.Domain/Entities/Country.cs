﻿namespace Hahn.ApplicatonProcess.February2021.Domain.Entities
{
    public class Country
    {
        public string Name { get; set; }
    }
    public class Department
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
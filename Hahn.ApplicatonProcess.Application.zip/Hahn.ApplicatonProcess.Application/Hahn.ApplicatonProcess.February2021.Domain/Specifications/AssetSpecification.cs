﻿using Hahn.ApplicatonProcess.February2021.Domain.Entities;

namespace Hahn.ApplicatonProcess.February2021.Domain.Specifications
{
    public class AssetSpecification : BaseSpecification<Asset>
    {
        public AssetSpecification() : base()
        {
        }
    }
}
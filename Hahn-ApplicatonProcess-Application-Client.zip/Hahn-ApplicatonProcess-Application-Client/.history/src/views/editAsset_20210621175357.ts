import {
  inject,
  CompositionTransaction,
  CompositionTransactionNotifier,
} from "aurelia-framework";
import { Router } from "aurelia-router";
import { EventAggregator } from "aurelia-event-aggregator";
import { AssetService } from "../services/assetService";
import { Asset } from "../entities/asset";
import { DialogService } from "aurelia-dialog";
import { Dialog } from "./dialog";
import * as moment from 'moment';
import { I18N } from "aurelia-i18n";

import {
  ValidationControllerFactory,
  ValidationRules,
} from "aurelia-validation";

import { BootstrapFormRenderer } from "../resources/bootstrap-form-renderer";

@inject(
  AssetService,
  ValidationControllerFactory,
  CompositionTransaction,
  Router,
  I18N,
  DialogService,
  EventAggregator,
  Asset
)
export class EditAsset {
  private assetervice: AssetService;
  private controllerFactory: ValidationControllerFactory;
  private notifier: CompositionTransactionNotifier;
  private router: Router;
  private i18N: I18N;
  private dialogService: DialogService;
  private ea: EventAggregator;
  controller = null;
  title: any;
  validation: any;
  standardGetMessage: any;
  asset: any;
  data: any;
  maxDate : string;
  minDate : string;
  purchaseDateValue : string;
  countriesList : any;
  departmentList : any;

  constructor(
    assetervice,
    controllerFactory,
    compositionTransaction,
    router,
    i18N,
    dialogService,
    ea,
    private app: Asset
  ) {
    this.assetervice = assetervice;
    this.controller = controllerFactory.createForCurrentScope();
    this.controller.addRenderer(new BootstrapFormRenderer());
    this.notifier = compositionTransaction.enlist();
    this.router = router;
    this.title = "Edit Asset";
    this.i18N = i18N;
    this.dialogService = dialogService;
    this.ea = ea;
    this.asset = app;
    this.minDate = (moment().add(-364, 'days')).format('yyyy-MM-DD')
    this.maxDate = (moment(new Date())).format('yyyy-MM-DD');
    // this.purchaseDateValue = this.maxDate;
    if (localStorage.getItem("department") === null) {
      this.departmentList = this.assetervice.getDepartment();
    }
    else{
      this.departmentList = JSON.parse(localStorage.getItem("department"))
    }
  }
  attached(): void {}
  action(): void {
    this.clearData();
  }

  public openDialog() {
    this.dialogService
      .open({
        viewModel: Dialog,
        model: "are you really sure to reset all the data",
      })
      .whenClosed()
      .then((respose) => {
        this.action();
      });
  }

  isChecked(value) {
    this.asset.broken = value;
  }

  clearData() {
    this.asset = null;
    this.router.navigateToRoute("AssetList");
  }

  //enable send button when form validation is done
  get canSave() {
    return (
      this.asset.assetName &&
      this.asset.department &&
      this.asset.countryOfDepartment &&
      this.asset.eMailAdressOfDepartment
    );
  }

  async searchById(id) {
     
    await this.assetervice
      .getAssetById(id)
      .then((response) => (this.data = response));
    this.data.forEach((element) => (this.asset = element));
    this.asset.purchaseDate = moment(this.asset.purchaseDate).format('YYYY-MM-DD')
    console.log(this.asset);
  }

  checkValidcountry = (countryName) => {
    try {
      var data = JSON.parse(localStorage.getItem("countries"));

      if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
          var cName = data[i];
          console.log(cName);
          if (
            cName.name.toLowerCase() == countryName.toLowerCase() ||
            cName.name.toUpperCase() == countryName.toUpperCase()
          ) {
            var valid = 1;
            break;
          }
        }
      }
    } catch (error) {
      console.log(error);
    }
    return valid;
  };

  activate = async (params) => {
    try {
      if (localStorage.getItem("countries") === null) {
        await this.assetervice.getCountry();
      }
      await this.searchById(params.id);
      this.notifier.done();
      this.setupValidation();
    } catch (error) {
      console.log(error);
    }
  };

  setupValidation() {
    //Custom validation for checking between two numbers
    ValidationRules.customRule(
      "integerRange",
      (value, obj, min, max) => {
        var num = Number.parseInt(value);
        return (
          num === null ||
          num === undefined ||
          (Number.isInteger(num) && num >= min && num <= max)
        );
      },
      "${$displayName} must be an integer between ${$config.min} and ${$config.max}.",
      (min, max) => ({ min, max })
    );

    //validation rules starts from here
    ValidationRules.ensure("assetName")
    .displayName("assetName")
    .required().withMessage("Please provide Asset name.")
    .minLength(5)
    .withMessage("Please provide Asset name with at least 5 Characters.")

    .ensure("department")
    .displayName("department")
    .required().withMessage("Please provide department.")
    
    .ensure("countryOfDepartment")
    .required().withMessage("Please provide Country Name.")

  .ensure("emailAdressOfDepartment")
    .required().withMessage("Please provide Email.")
    .email().withMessage("Please provide valid Email.")

  .ensure("purchaseDate")
    .required()
    .withMessage("Please provide date.")
  .on(this.asset);
  }

  //this function will fire when user click the submit button
  execute = async () => {
    try {
       
      var res = await this.controller.validate();

      if (res.valid) {
        this.update();
      }
    } catch (error) {
      console.log(error);
    }
  };

  update = async () => {
    var result = this.checkValidcountry(this.asset.countryOfDepartment);
    try {
      if (result == 1) {
        this.asset.purchaseDate = new Date(this.asset.purchaseDate);
        try {
          await this.assetervice
            .updateAsset(this.asset)
            .then((response) => {
               
              if (response.statusCode == 201) {
                this.router.navigateToRoute("AssetList");
              } else {
                alert("Something went wrong!!!");
              }
            });
        } catch (error) {
          console.log(error);
        }
      } else {
        alert("Country not found");
      }
    } catch (error) {
      console.log(error);
    }
  };
  keyDownInDate(e){
    return false;
  }
  search(){
    var data = JSON.parse(localStorage.getItem("countries"));
    this.countriesList = data.filter(usr => usr.name.toLowerCase().includes(this.asset.countryOfDepartment.toLowerCase()));
   }
}
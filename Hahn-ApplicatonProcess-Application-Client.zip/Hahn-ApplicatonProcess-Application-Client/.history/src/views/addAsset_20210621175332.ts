import {
  inject,
  CompositionTransaction,
  CompositionTransactionNotifier,
} from "aurelia-framework";
import { Router } from "aurelia-router";
import { EventAggregator } from "aurelia-event-aggregator";
import { AssetService } from "../services/assetService";
import { Asset } from "../entities/asset";
import { DialogService } from "aurelia-dialog";
import { Dialog } from "./dialog";
import * as moment from 'moment';
import { I18N } from "aurelia-i18n";

import {
  ValidationControllerFactory,
  ValidationRules,
} from "aurelia-validation";

import { BootstrapFormRenderer } from "../resources/bootstrap-form-renderer";

@inject(
  AssetService,
  ValidationControllerFactory,
  CompositionTransaction,
  Router,
  I18N,
  DialogService,
  EventAggregator,
  Asset
)
export class AddAsset {
  private assetervice: AssetService;
  private controllerFactory: ValidationControllerFactory;
  private notifier: CompositionTransactionNotifier;
  private router: Router;
  private i18N: I18N;
  private dialogService: DialogService;
  private ea: EventAggregator;
  controller = null;
  title: any;
  validation: any;
  standardGetMessage: any;
  asset: any;
  maxDate : string;
  minDate : string;
  purchaseDateValue : string;
  countriesList : any;
  departmentList : any;

  constructor(assetervice, controllerFactory, compositionTransaction, router, i18N, dialogService, ea, private app: Asset) {
    this.assetervice = assetervice;
    this.controller = controllerFactory.createForCurrentScope();
    this.controller.addRenderer(new BootstrapFormRenderer());
    this.notifier = compositionTransaction.enlist();
    this.router = router;
    this.title = "Add New Asset";
    this.i18N = i18N;
    this.dialogService = dialogService;
    this.ea = ea;
    this.asset = app;
    this.minDate = (moment().add(-364, 'days')).format('yyyy-MM-DD')
    this.maxDate = (moment(new Date())).format('yyyy-MM-DD');
    this.purchaseDateValue = this.maxDate;
    if (localStorage.getItem("department") === null) {
      this.departmentList = this.assetervice.getDepartment();
    }
    else{
      this.departmentList = JSON.parse(localStorage.getItem("department"))
    }
  }
  attached(): void {}
  action(): void {
    this.clearData();
  }

  public openDialog() {
    this.dialogService
      .open({
        viewModel: Dialog,
        model: "are you really sure to reset all the data",
      })
      .whenClosed()
      .then((respose) => {
        console.log(respose);
        this.action();
      });
  }

  isChecked(value) {
    this.asset.broken = value;
  }

  clearData() {
    this.asset = new Asset;
    this.countriesList = [];
    this.asset.purchaseDate = this.maxDate;
    this.setupValidation();
  }

  //enable send button when form validation is done
  get canSave() {
    return (
      this.asset.assetName &&
      this.asset.department &&
      this.asset.countryOfDepartment &&
      this.asset.emailAdressOfDepartment //&&
      // (this.asset.purchaseDate <= (new Date()) ||
      // this.asset.purchaseDate >= (moment().add(-30, 'days')))
    );
  }

  //enable reset button when user type something
  get canReset() {
    return (
      this.asset.assetName ||
      this.asset.department ||
      this.asset.countryOfDepartment ||
      this.asset.emailAdressOfDepartment ||
      this.asset.purchaseDate
    );
  }

  async searchById(id) {
    await this.assetervice
      .getAssetById(id)
      .then((response) => (this.asset = response));
  }

  checkValidcountry = (countryName) => {
    try {
      var data = JSON.parse(localStorage.getItem("countries"));

      if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
          var cName = data[i];

          if (
            cName.name.toLowerCase() == countryName.toLowerCase() ||
            cName.name.toUpperCase() == countryName.toUpperCase()
          ) {
            var valid = 1;
            break;
          }
        }
      }
    } catch (error) {
      console.log(error);
    }
    return valid;
  };

  activate = async () => {
    try {
      if (localStorage.getItem("countries") === null) {
        await this.assetervice.getCountry();
      }
      this.notifier.done();
      await this.setupValidation();
    } catch (error) {
      console.log(error);
    }
  };

  setupValidation() {
    //Custom validation for checking between two numbers
    ValidationRules.customRule(
      "integerRange",
      (value, obj, min, max) => {
        var num = Number.parseInt(value);
        return (
          num === null ||
          num === undefined ||
          (Number.isInteger(num) && num >= min && num <= max)
        );
      },
      "${$displayName} must be an integer between ${$config.min} and ${$config.max}.",
      (min, max) => ({ min, max })
    );

    ValidationRules.customRule(
      "departmentValue",
      (value) => {
        console.log(value);
        return (
          value !== null ||
          value !== undefined ||
          value !== ""
        );
      },
      "Please provide department."
    );
    //validation rules starts from here
    ValidationRules.ensure("assetName")
      .displayName("assetName")
      .required().withMessage("Please provide Asset name.")
      .minLength(5).withMessage("Please provide Asset name with at least 5 Characters.")

      .ensure("department")
      .displayName("department")
      .required().withMessage("Please provide department.")
      // .required().satisfiesRule('departmentValue').withMessage('Please provide department.')
      //   .satisfies(
      //     () =>
      //         this.asset.department.filter(
      //             (item) => item === ""
      //         ).length !== 0 && this.asset.department !== ""
      // ).withMessage('Please provide department.')

      .ensure("countryOfDepartment")
      .required().withMessage("Please provide Country Name.")

    .ensure("emailAdressOfDepartment")
      .required().withMessage("Please provide Email.")
      .email().withMessage("Please provide valid Email.")

    .ensure("purchaseDate")
      .required()
      .withMessage("Please provide date.")
    .on(this.asset);
  }

  //this function will fire when user click the submit button
  execute = async () => {
    try {
      var res = await this.controller.validate();

      if (res.valid) {
        this.create();
      }
    } catch (error) {
      console.log(error);
    }
  };

  create = async () => {
    try {
      var result = this.checkValidcountry(this.asset.countryOfDepartment);

      if (result == 1) {
        this.asset.purchaseDate = new Date(this.asset.purchaseDate);

        await this.assetervice
          .addAsset(this.asset)
          .then((response) => {
            debugger;
            if (response == undefined) {
              alert(
                "Something went wrong! Please check your internet connection..."
              );
            } else if (response.statusCode == 201) {
              this.clearData();
              this.router.navigateToRoute("AssetList");
            } else {
              alert("Something went wrong!!!");
            }
          });
      } else {
        alert("Country not found");
      }
    } catch (error) {
      console.log(error);
    }
  };
  keyDownInDate(e){
    return false;
  }
  search(){
    var data = JSON.parse(localStorage.getItem("countries"));
    this.countriesList = data.filter(usr => usr.name.toLowerCase().includes(this.asset.countryOfDepartment.toLowerCase()));
   }
}

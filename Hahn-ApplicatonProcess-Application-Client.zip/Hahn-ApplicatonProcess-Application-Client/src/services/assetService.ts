import { HttpClient, json } from "aurelia-fetch-client";
import { inject } from "aurelia-framework";
import { api } from "../config/api";

@inject(HttpClient)
export class AssetService {
  private http: HttpClient;
  assets: [];
  countries: [];

  constructor(http: HttpClient) {
    http.configure((config) => {
      config
        .withBaseUrl(api.baseUrl)
        .withDefaults({
          credentials: "same-origin",
          headers: {
            Accept: "application/json",
            "X-Requested-With": "Fetch",
          },
        })
        .withInterceptor({
          request(request) {
            console.log(`Requesting ${request.method} ${request.url}`);
            return request; // you can return a modified Request, or you can short-circuit the request by returning a Response
          },
          response(response) {
            console.log(`Received ${response.status} ${response.url}`);
            return response; // you can return a modified Response
          },
        });
    });
    this.http = http;
  }

  addAsset(asset) {
    return this.http
      .fetch("asset", {
        method: "post",
        body: json(asset),
      })
      .then((response) => response.json())
      .then((responseMessage) => {
        return responseMessage;
      })
      .catch((error) => {
        console.log("Facing error while saving asset", error);
      });
  }

  deleteAsset(id) {
    return this.http
      .fetch(`asset/${id}`, {
        method: "delete",
      })
      .then((response) => response.json())
      .then((responseMessage) => {
        return responseMessage;
      })
      .catch((error) => {
        console.log("Facing error while deleting asset", error);
      });
  }

  updateAsset(asset) {
    return this.http
      .fetch(`asset/${asset.id}`, {
        method: "put",
        body: json(asset),
      })
      .then((response) => response.json())
      .then((responseMessage) => {
        return responseMessage;
      })
      .catch((error) => {
        console.log("Facing error while updating asset", error);
      });
  }

  getAsset() {
    return this.http
      .fetch("asset", {
        method: "get",
      })
      .then((response) => response.json())
      .then((assets) => {
        return assets;
      })
      .catch((error) => {
        console.log("Facing error while retrieving asset.", error);
        return [];
      });
  }

  getAssetById(id) {
    return this.http
      .fetch(`asset/${id}`)
      .then((response) => response.json())
      .then((assets) => {
        return assets;
      })
      .catch((error) => {
        console.log("Facing error while retrieving asset.", error);
        return [];
      });
  }

  getCountry() {
     
    return this.http
      .fetch("asset/GetCountry", {
        method: "get",
      })
      .then((response) => response.json())
      .then((countries) => {
         
        console.log("Fetching... ", countries);
        localStorage.setItem("countries", JSON.stringify(countries));

        return countries;
      })

      .catch((error) => {
        console.log("Facing error while retrieving countires.", error);
        return [];
      });
  }

  getDepartment() {
    return this.http
      .fetch("asset/GetDepartment", {
        method: "get",
      })
      .then((response) => response.json())
      .then((departments) => {
        localStorage.setItem("department", JSON.stringify(departments));
        return departments;
      })
      .catch((error) => {
        console.log("Facing error while retrieving departments.", error);
        return [];
      });
  }
}

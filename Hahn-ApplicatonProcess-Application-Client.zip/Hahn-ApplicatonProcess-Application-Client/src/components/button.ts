export class Button {
  constructor() {}
}

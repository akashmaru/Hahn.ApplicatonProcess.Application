export class TableHeader {
  constructor() {}
}

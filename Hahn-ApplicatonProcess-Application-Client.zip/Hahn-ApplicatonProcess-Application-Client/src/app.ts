import { PLATFORM } from "aurelia-framework";
import { Router, RouterConfiguration } from "aurelia-router";

export class App {
  router: Router | undefined;
  configureRouter(config: RouterConfiguration, router: Router) {
    config.title = "Hahn Asset Process";
    config.options.pushState = true;
    //config.options.root = "/";
    config.map([
      {
        route: ["", "asset-add"],
        name: "AddAsset",
        moduleId: PLATFORM.moduleName("views/addAsset"),
        title: "Add New Asset",
        nav: true,
      },

      {
        route: ["asset-list"],
        name: "AssetList",
        moduleId: PLATFORM.moduleName("views/assetList"),
        title: "Asset List",
        nav: true,
      },

      {
        route: ["asset-edit/:id"],
        name: "EditAsset",
        title: "Edit Asset",
        moduleId: PLATFORM.moduleName("views/editAsset"),
      },
    ]);

    this.router = router;
  }
}

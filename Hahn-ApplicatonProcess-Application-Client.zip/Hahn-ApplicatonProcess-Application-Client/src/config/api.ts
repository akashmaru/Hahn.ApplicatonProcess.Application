export const api = {
  baseUrl: "http://localhost:60148/api/",
};

import { inject, bindable } from "aurelia-framework";
import { EventAggregator } from "aurelia-event-aggregator";
import { Router } from "aurelia-router";
import { AssetService } from "../services/assetService";
import { DialogService } from "aurelia-dialog";
import { Dialog } from "./dialog";
import { I18N } from "aurelia-i18n";
import * as moment from 'moment';
import { Asset } from "entities/asset";

@inject(Router, AssetService, DialogService, I18N, EventAggregator)
export class AssetList {
  private i18n = [I18N];
  private assetService: AssetService;
  private router: Router;
  private dlg: DialogService;
  private ea: EventAggregator;
  title: any;
  assets: any;
  assetsList: any;
  searchBy: number;
  selectedId: any;

  constructor(router, assetService, dlg, i18n, ea) {
    this.router = router;
    this.assetService = assetService;
    this.dlg = dlg;
    this.i18n = i18n;
    this.ea = ea;
    this.title = "Asset List";
  }

  @bindable
  action = async (id) => {
    await this.assetService.deleteAsset(id).then(async (response) => {
      if (response.statusCode != 201) {
        alert("Something went wrong!!!");
      }
      await this.search();
    });
    return true;
  };

  @bindable
  msg = "Are you sure";

  activate() {
    try {
      this.search();
    } catch (error) {
      console.log(error);
    }
  }

  async search() {
    await this.assetService
      .getAsset()
      .then((response) => (this.assetsList = response));
      this.assets = this.assetsList;
    return true;
  }

  async searchById(searchText) {
    this.assets = this.assetsList.filter(x => x.assetName.toLowerCase().includes(searchText.toLowerCase()) 
                                            || x.department.toLowerCase().includes(searchText.toLowerCase())
                                            || x.countryOfDepartment.toLowerCase().includes(searchText.toLowerCase())
                                            || x.eMailAdressOfDepartment.toLowerCase().includes(searchText.toLowerCase()));
    // await this.assetService
    //   .getAssetById(searchText)
    //   .then((response) => (this.assets = response));
    // console.log(this.assets);
    return true;
  }

  removeAsset = async (id) => {
    this.dlg
      .open({
        viewModel: Dialog,
        model: this.msg,
      })
      .whenClosed()
      .then(async (result) => {
        if (!result.wasCancelled) {
          await this.assetService.deleteAsset(id);
          await this.search();
        } else {
          console.log("cancelled");
        }
      });
  };

  formateDate(purchaseDate) {
    return moment(purchaseDate).format('DD/MM/YYYY');
 }
}

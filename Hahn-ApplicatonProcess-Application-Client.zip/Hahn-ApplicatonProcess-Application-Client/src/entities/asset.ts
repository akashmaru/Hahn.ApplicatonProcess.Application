export class Asset {
  id: number;
  assetname: string;
  department: string;
  countryOfDepartment: string;
  eMailAdressOfDepartment: string;
  purchaseDate: Date;
  broken: boolean;
}
